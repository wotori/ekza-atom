var scene = new THREE.Scene();
var camera = new THREE.PerspectiveCamera( 75, window.innerWidth/window.innerHeight, 0.1, 1000 );
camera.position.set (0, 0, 10)

//setup Orbit
var controls = new THREE.OrbitControls( camera );
controls.zoomSpeed = 0.1
controls.rotateSpeed = 0.1
controls.enableZoom = true
controls.enableRotate = false
// controls.target.set(0, 3, 0)



var renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );

var geometry = new THREE.BoxGeometry( 1, 1, 1 );
var material = new THREE.MeshBasicMaterial( { color: 0x00ff00 } );
var cube = new THREE.Mesh( geometry, material );
scene.add( cube );

var geo2 = new THREE.SphereGeometry(1, 5, 5);
var sphere = new THREE.Mesh (geo2, material)
scene.add( sphere )
sphere.position.set(-3, -3, 3)

//zoom experement
//camera.position = Vector3 {x: 0, y: 8.277568726233369e-17, z: 1.3518295613064166}

var cameraZoom = function() {
    i = 0
    while ( i < 10) {
        camera.position.z -= 0.1;
        console.log(camera.position)
        i++;
    }
}


var animate = function () {
    requestAnimationFrame( animate );
    // camera.position.set (0, 0, 0)
    // console.log (camera.position)
    
    controls.update()

	// cube.rotation.x += 0.01;
    // cube.rotation.y += 0.01;

    // camera.position.z -= 0.1
    // cameraZoom()
    
	renderer.render( scene, camera );
};

animate();