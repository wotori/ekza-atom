

			//camera
			// camera.position.x += ( MOUSE.x - camera.position.x ) * .05;
			// camera.position.y += ( MOUSE.y - camera.position.y ) * .05;